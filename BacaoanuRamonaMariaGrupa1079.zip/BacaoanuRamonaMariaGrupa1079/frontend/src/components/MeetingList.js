import {useState, useEffect} from 'react'
import {get, post, put, remove } from '../Calls'
import {Button, Paper, Table, TableBody, TableCell, MenuItem,TableRow, TableContainer, InputLabel, Select, Grid, TextField, TableHead, IconButton } from '@material-ui/core'
import DeleteIcon from '@material-ui/icons/Delete'
import EditIcon from '@material-ui/icons/Edit'
import RemoveRedEyeIcon from '@material-ui/icons/RemoveRedEye'
import SaveIcon from '@material-ui/icons/Save'
import SortIcon from '@material-ui/icons/Sort'
import {link,meetingRoute,getMeetingRoute} from '../ApiRoutes'
import {useNavigate } from 'react-router-dom'

export default function MeetingList(){
    const [meetingEdit, setMeetingEdit] = useState
    ({
        id:0,
        descriere:"",
        url:"",
        data:""
    })
    const [sortare] = useState
    ({
        camp:"data",
        asc:"asc"
    });
    const [rows, setRows] = useState([]);
    const [needUpdate, setNeedUpdate] = useState(false)
    const navigate = useNavigate();

    useEffect(async() => {
        let data = await get(getMeetingRoute);
        setRows(data);
    }, [needUpdate]);

    function formatData(d){
        let data=new Date(d);
        let zi=data.getDate();
        let luna=data.getMonth()+1;
        let an=data.getFullYear();
        let da=an+"-"+luna+"-"+zi;
        return da;
    }

    const deleteMeeting= async(idMeeting, index) => {
        await remove(meetingRoute,idMeeting);
        meetingEdit.id="";
        meetingEdit.descriere="";
        meetingEdit.url="";
        meetingEdit.data="";
        rows.splice(index, 1);
        setRows(rows);
        setNeedUpdate(!needUpdate);
    } 

    const onChangeMeetingEdit = e => {
        setMeetingEdit({...meetingEdit, [e.target.name]: e.target.value});
    }
    const saveMeetingEdit = async () => {
        if(meetingEdit.descriere.length>3){
            await put(meetingRoute, meetingEdit.idMeeting, meetingEdit);
            setNeedUpdate(!needUpdate);}
            else
            alert("Descrierea trebuie sa aiba cel putin 3 caractere!");
    }
    const handleChangeCamp = (event) => {
        sortare.camp=event.target.value 
        setNeedUpdate(!needUpdate)
      }
      const handleChangeAsc = (event) => {
        sortare.asc=event.target.value
        setNeedUpdate(!needUpdate)
      }
      const sort = async () => { 
        let d = await get(link+"sortedMeeting/"+sortare.camp+"/"+sortare.asc)
        setRows(d)
        }
    return (
        <div>
           <Grid container spacing={3}>
                <Grid item xs={4} sm={4}>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="idMeeting"
                        name="idMeeting"
                        label="Id meeting"
                        type="number"
                        fullWidth
                        value={meetingEdit.idMeeting}
                        onChange={e => onChangeMeetingEdit(e)}
                        />
                </Grid>
                <Grid item xs={4} sm={4}>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="descriere"
                        name="descriere"
                        label="Descriere"
                        fullWidth
                        value={meetingEdit.descriere}
                        onChange={e => onChangeMeetingEdit(e)}
                        />
                </Grid>
                <Grid item xs={4} sm={4}>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="url"
                        name="url"
                        label="Url"
                        fullWidth
                        value={meetingEdit.url}
                        onChange={e => onChangeMeetingEdit(e)}
                        />
                </Grid>
                <Grid item xs={4} sm={4}>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="data"
                        name="data"
                        label="Data"
                        type="date"
                        fullWidth
                        value={meetingEdit.data}
                        onChange={e => onChangeMeetingEdit(e)}
                        />
                </Grid>
            </Grid>
            <Button color="primary" variant='outlined' startIcon={<SaveIcon />}
                onClick={saveMeetingEdit}
            >
                UPDATE
            </Button> 
            <br/>
            <br/>
            <br/>

            <Grid container spacing={3} >
                <Grid item xs={2} sm={2}>
                    <InputLabel id="selectCampLabel">Camp</InputLabel>
                    <Select
                        labelId="selectCampLabel"
                        id="selectCamp"
                        value={sortare.camp}
                        label="Camp Sortare"
                        onChange={handleChangeCamp}
                        >
                        <MenuItem value={"idMeeting"}>Id meeting</MenuItem>
                        <MenuItem value={"descriere"}>Descriere</MenuItem>
                        <MenuItem value={"url"}>Url</MenuItem>
                        <MenuItem value={"data"}>Data</MenuItem> 
                    </Select>
                </Grid>
                <Grid item xs={2} sm={2}>
                    <InputLabel id="selectAscLabel">ASC/DESC</InputLabel>
                    <Select
                        labelId="selectAscLabel"
                        id="selectAsc"
                        value={sortare.asc}
                        label="Mod Sortare"
                        onChange={handleChangeAsc}
                        >
                        <MenuItem value={"asc"}>ASC</MenuItem>
                        <MenuItem value={"desc"}>DESC</MenuItem>
                    </Select>
                </Grid>
                <Button color="primary" variant='outlined' startIcon={<SortIcon />}
                onClick={sort}
            >
               SORTARE
            </Button> 
            </Grid>
            <br/>
            <Grid container spacing={3}>
            <Grid item xs={12} sm={12} >
            <TableContainer component={Paper}>
                <Table aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Id meeting</TableCell>
                            <TableCell align="right">Descriere</TableCell>
                            <TableCell align="right">Url</TableCell>
                            <TableCell align="right">Data </TableCell>
                            <TableCell align="right">Editare meeting</TableCell>    
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row, index) => 
                                <TableRow key={row.ZooId}>
                                <TableCell component="th" scope ="row">
                                    {row.idMeeting}
                                </TableCell>
                                <TableCell align="right">{row.descriere}</TableCell>
                                <TableCell align="right">{row.url}</TableCell>
                                <TableCell align="right">{formatData(row.data)}</TableCell>
                                <TableCell align="right">
                                   <IconButton onClick={() => {meetingEdit.idMeeting=row.idMeeting; 
                                   meetingEdit.descriere=row.descriere; 
                                   meetingEdit.url=row.url;  
                                   meetingEdit.data=row.data;
                                   setNeedUpdate(!needUpdate);
                                }}>
                                       <EditIcon color="primary"/>
                                   </IconButton>
                                   <IconButton onClick={() => deleteMeeting(row.idMeeting, index)}>
                                       <DeleteIcon color="secondary" />
                                   </IconButton>  
                                </TableCell> 
                            </TableRow> 
                        )}
                    </TableBody>
                </Table>
            </TableContainer>
          </Grid>
          </Grid>
        </div>
    )
}