const link = "http://localhost:8000/api/"
const meetingRoute = link + "meeting"
const participantRoute = link + "participant"
const getMeetingRoute = link + "meetings";

export {link,meetingRoute,participantRoute,getMeetingRoute}