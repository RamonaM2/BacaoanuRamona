export const DB_USERNAME='root'
export const DB_PASSWORD='BRMparola2'