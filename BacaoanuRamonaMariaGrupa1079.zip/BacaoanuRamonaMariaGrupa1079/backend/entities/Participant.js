import db from '../dbConfig.js'
import Sequelize from 'sequelize'

const Participant = db.define('Participant', {
    idParticipant:
    {
        type: Sequelize.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    nume:{
        type: Sequelize.STRING,
        allowNull: false,
        validate: {
            len: {
                min:5
           }
        }
    },
    idMeeting:{
        type: Sequelize.INTEGER,      
        allowNull: false
    }
})

export default Participant
