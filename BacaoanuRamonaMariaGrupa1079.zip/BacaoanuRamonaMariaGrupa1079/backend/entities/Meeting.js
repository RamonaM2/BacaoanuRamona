import db from '../dbConfig.js'
import Sequelize from 'sequelize'

const Meeting = db.define('Meeting', {
    idMeeting:
    {
        type: Sequelize.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    descriere:{
        type: Sequelize.STRING,
        allowNull: false,
        validate: {
            len: {
                min:3
           }
        }
    },
    url:{
        type: Sequelize.STRING,
        allowNull: false,
        validate:{
            isUrl:true
        }
    },
    data:{
        type: Sequelize.DATEONLY,
        allowNull: false
    } 
})

export default Meeting
