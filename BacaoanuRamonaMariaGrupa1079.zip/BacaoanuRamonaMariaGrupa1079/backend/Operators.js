import Sequelize from 'sequelize'

const LikeOp = Sequelize.Op.like

export default LikeOp